package e1;

public class Second_largest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
